# react-jinke-music-player
a example

```
$ npm run demo :)
```
