export const THEME = {
  LIGHT: 'light',
  DARK: 'dark',
  AUTO: 'auto',
}
