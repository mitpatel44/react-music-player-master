export const DEFAULT_PLAY_INDEX = 0
export const DEFAULT_VOLUME = 1
export const DEFAULT_REMOVE_ID = -1
export const PLAYER_KEY = '__PLAYER_KEY__'
