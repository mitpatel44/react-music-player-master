export const VOLUME_FADE = {
  IN: 'in',
  OUT: 'out',
  NONE: 'none',
}
