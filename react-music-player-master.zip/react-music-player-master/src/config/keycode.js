export const SPACE_BAR_KEYCODE = 32
